using UnityEngine;
using SB4b1.Logging;

namespace SBGames.AI
{
    /// <summary>
    /// Governs the AI strategic reaction time and decision frequency.
    /// Throttles SensorToolkit perception queries and Utility AI / GOAP goal selection
    /// while allowing movement, physics, and animations to run smoothly at full frame rate.
    /// </summary>
    [RequireComponent(typeof(BaseAI))]
    [DisallowMultipleComponent]
    public class AIDecisionThrottler : MonoBehaviour
    {
        [Header("Components")]
        [SerializeField] private BaseAI baseAI;
        [SerializeField] private VisionController visionController;
        [SerializeField] private CharacterBrain characterBrain;
        [SerializeField] private CharacterStatsManager statsManager;

        [Header("Fallback Defaults (if CharacterStatsManager is not present)")]
        [SerializeField, Min(0.05f)] private float defaultDecisionInterval = 0.3f;
        [SerializeField, Range(0f, 0.5f)] private float defaultIntervalJitter = 0.05f;
        [SerializeField, Min(0f)] private float defaultActionCommitmentDuration = 0.4f;

        [Header("Runtime Status (Read-Only)")]
        [SerializeField] private float nextDecisionTime;
        [SerializeField] private float actionCommitmentTimer;
        [SerializeField] private bool isDecisionLocked;

        public float DecisionInterval => statsManager != null && statsManager.DecisionInterval != null
            ? statsManager.DecisionInterval.Value
            : defaultDecisionInterval;

        public float IntervalJitter => statsManager != null && statsManager.IntervalJitter != null
            ? statsManager.IntervalJitter.Value
            : defaultIntervalJitter;

        public float ActionCommitmentDuration => statsManager != null && statsManager.ActionCommitmentDuration != null
            ? statsManager.ActionCommitmentDuration.Value
            : defaultActionCommitmentDuration;

        public bool IsActionLocked => isDecisionLocked || actionCommitmentTimer > 0f ||
            (characterBrain != null && (characterBrain.IsAttacking || characterBrain.IsCastingSkill));

        private void Awake()
        {
            ResolveDependencies();
        }

        private void OnEnable()
        {
            ResolveDependencies();

            if (statsManager != null)
            {
                statsManager.OnCharacterDeath += HandleCharacterDeath;
            }

            // Stagger initial execution randomly across agents to eliminate frame spikes on spawn
            float initialInterval = Mathf.Max(0.05f, DecisionInterval);
            nextDecisionTime = Time.time + Random.Range(0f, initialInterval);
            actionCommitmentTimer = 0f;
        }

        private void OnDisable()
        {
            if (statsManager != null)
            {
                statsManager.OnCharacterDeath -= HandleCharacterDeath;
            }
        }

        private void Update()
        {
            // Update action commitment timer
            if (actionCommitmentTimer > 0f)
            {
                actionCommitmentTimer -= Time.deltaTime;
                if (actionCommitmentTimer < 0f) actionCommitmentTimer = 0f;
            }

            // Verify if character is active and alive
            if (characterBrain != null && characterBrain.AgentStatus != AgentStatus.Active)
            {
                return;
            }

            // Check if it is time to perform a decision cycle
            if (Time.time < nextDecisionTime)
            {
                return;
            }

            // Anti-Flapping / Action Commitment Gate:
            // If the agent is currently executing an attack or skill, or commitment window is active,
            // defer strategic re-evaluation until the active action finishes or commitment timer expires.
            if (IsActionLocked)
            {
                // Defer by a small fraction (e.g. 0.05s) to re-check cleanly without spinning every frame
                nextDecisionTime = Time.time + 0.05f;
                return;
            }

            // Execute the synchronized strategic tick
            ExecuteStrategicTick();

            // Calculate next interval with jitter to prevent agent synchronization
            float baseInterval = Mathf.Max(0.05f, DecisionInterval);
            float jitter = Mathf.Clamp(IntervalJitter, 0f, baseInterval * 0.5f);
            float randomJitter = Random.Range(-jitter, jitter);
            float randomizedInterval = Mathf.Max(0.05f, baseInterval + randomJitter);

            nextDecisionTime = Time.time + randomizedInterval;
        }

        /// <summary>
        /// Orchestrates the perception scan and GOAP / Utility AI decision evaluation in a single tick.
        /// Zero allocations during execution.
        /// </summary>
        private void ExecuteStrategicTick()
        {
            // 1. Perception Pulse (SensorToolkit -> VisionController target caching)
            if (visionController != null)
            {
                visionController.TickPerception();
            }

            // 2. Utility AI Evaluation & GOAP Goal Planning
            if (baseAI != null)
            {
                baseAI.PerformStrategicDecision();
            }

            // 3. Apply Anti-Flapping Action Commitment window
            float commitmentTime = ActionCommitmentDuration;
            if (commitmentTime > 0f)
            {
                actionCommitmentTimer = commitmentTime;
            }
        }

        /// <summary>
        /// Locks strategic decision making for a custom duration (e.g., when casting a sustained skill).
        /// </summary>
        public void LockActionCommitment(float duration = -1f)
        {
            actionCommitmentTimer = duration > 0f ? duration : ActionCommitmentDuration;
        }

        /// <summary>
        /// Immediately breaks action commitment locks and resets decision timing.
        /// Triggered by severe combat events like Stuns, Knockbacks, or Damage interruptions.
        /// </summary>
        public void InterruptDecisionLock()
        {
            actionCommitmentTimer = 0f;
            isDecisionLocked = false;

            if (baseAI != null)
            {
                baseAI.InterruptCurrentPlan();
            }

            // Force immediate re-evaluation on next frame
            nextDecisionTime = Time.time;
        }

        private void HandleCharacterDeath(CharacterStatsManager stats)
        {
            actionCommitmentTimer = 0f;
            isDecisionLocked = true;

            if (baseAI != null)
            {
                baseAI.InterruptCurrentPlan();
            }
        }

        private void ResolveDependencies()
        {
            if (baseAI == null) baseAI = GetComponent<BaseAI>();
            if (visionController == null) visionController = GetComponent<VisionController>();
            if (visionController == null) visionController = GetComponentInChildren<VisionController>();

            if (characterBrain == null) characterBrain = GetComponentInParent<CharacterBrain>();
            if (statsManager == null) statsManager = GetComponentInParent<CharacterStatsManager>();
        }
    }
}
