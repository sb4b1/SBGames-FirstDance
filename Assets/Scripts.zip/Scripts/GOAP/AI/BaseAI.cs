using System.Collections.Generic;
using CrashKonijn.Agent.Runtime;
using CrashKonijn.Goap.Runtime;
using SB4b1.Helpers;
using SBGames.Personality;
using UnityEngine;
using UnityEngine.AI;

[RequireComponent(typeof(GoapActionProvider))]
public class BaseAI : MonoBehaviour
{
    [SerializeField] private NavMeshAgent agent;
    [SerializeField] private AgentBehaviour agentBehaviour;
    [SerializeField] private CharacterBrain brain;
    [SerializeField] private CharacterStatsManager stats;
    [SerializeField] private CharacterMovementController motionController;
    [SerializeField] private CharacterSkillController skillController;
    [SerializeField] private VisionController vision;
    [SerializeField] private SquadMember squadMember;
    [SerializeField] private List<UtilityGoal> goals;

    // Automatically populated from CharacterSkillController.Skills at runtime.
    // Each Skill's UtilityData (ScriptableObject) is collected here so SelectBestSkill can evaluate them.
    // You do NOT need to assign these manually in the Inspector.
    [SerializeField] private List<UtilitySkill> skills = new();

    [SerializeField] private CharacterPersonality personality;
    [SerializeField] private CharacterAIMemory aiMemory;

    public CharacterBrain Brain => brain ??= GetComponentInParent<CharacterBrain>();
    public CharacterStatsManager StatsManager => stats ??= GetComponentInParent<CharacterStatsManager>();
    public CharacterSkillController SkillController => skillController;
    public SquadMember SquadMember => squadMember ??= (GetComponent<SquadMember>() ?? GetComponentInParent<SquadMember>() ?? GetComponentInChildren<SquadMember>());
    public CharacterPersonality Personality => personality ??= (GetComponent<CharacterPersonality>() ?? GetComponentInParent<CharacterPersonality>() ?? GetComponentInChildren<CharacterPersonality>());
    public CharacterAIMemory AIMemory => aiMemory ??= (GetComponent<CharacterAIMemory>() ?? GetComponentInChildren<CharacterAIMemory>() ?? GetComponentInParent<CharacterAIMemory>());
    public List<UtilitySkill> Skills => skills;

    // --- Precomputed Zero-Alloc Personality Biases ---
    public float EffectiveThreatMultiplier => Personality != null ? Personality.Snapshot.ThreatMultiplier : 1.0f;
    public float EffectiveFearMultiplier => Personality != null ? Personality.Snapshot.FearMultiplier : 1.0f;
    public bool IsFearLocked => Personality != null && Personality.Snapshot.IsFearLocked;
    public float SurvivalHpThreshold => Personality != null ? Personality.Snapshot.SurvivalHpThreshold : 0.25f;
    public bool IgnoreSurvivalGoal => Personality != null && Personality.Snapshot.IgnoreSurvivalGoal;
    public int ClusterCountOffset => Personality != null ? Personality.Snapshot.ClusterCountOffset : 0;
    public float RangePreferenceMultiplier => Personality != null ? Personality.Snapshot.RangePreferenceMultiplier : 1.0f;
    public float ExecutionHealthThreshold => Personality != null ? Personality.Snapshot.ExecutionHealthThreshold : 0.30f;
    public float ExecutionBonusMultiplier => Personality != null ? Personality.Snapshot.ExecutionBonusMultiplier : 1.0f;
    public float PeelingHealthThreshold => Personality != null ? Personality.Snapshot.PeelingHealthThreshold : 0.35f;
    public float PeelingBonusMultiplier => Personality != null ? Personality.Snapshot.PeelingBonusMultiplier : 1.0f;
    public float LowHealthTargetPriority => Personality != null ? Personality.Snapshot.LowHealthTargetPriority : 1.0f;
    public float BleedingTargetPriority => Personality != null ? Personality.Snapshot.BleedingTargetPriority : 1.0f;

    /// <summary>True when at least one skill in the SkillController is off cooldown.</summary>
    public bool IsSkillReady => skillController != null && skillController.HasReadySkill();

    // This can be used to differentiate between different types of agents (e.g., "NormalAgent", "AggressiveAgent", etc.)
    // NormalAgent is the default type, and if no specific behavior is assigned in the GoapActionProvider, it will use the NormalAgent behavior
    [SerializeField] private string agentType = "NormalAgent";

    private GoapBehaviour goap;
    private GoapActionProvider provider;
    private EnumUtilGoal activeGoal = EnumUtilGoal.None;

    [SerializeField] private Transform currentTarget;
    [SerializeField] private float targetDistance;
    [SerializeField] private List<Transform> enemyTargets;
    [SerializeField] private List<Transform> allyTargets;

    public Transform CurrentTarget { get => currentTarget; private set => currentTarget = value; }
    public float TargetDistance { get => targetDistance; private set => targetDistance = value; }
    public List<Transform> EnemyTargets { get => enemyTargets; set => enemyTargets = value; }
    public List<Transform> AllyTargets { get => allyTargets; set => allyTargets = value; }

    [SerializeField] private List<KnownEnemyRecord> localKnownEnemies = new(8);
    [SerializeField] private bool hasAlertedAllies = true;
    [SerializeField] private float alertShoutRadius = 12f;
    [SerializeField] private float alertShoutCooldown = 4f;
    private float lastAlertShoutTime = -999f;
    private static readonly Collider2D[] proximityAlertBuffer = new Collider2D[16];

    public System.Action<Transform> OnAlertShout;

    public bool HasAlertedAllies { get => hasAlertedAllies; internal set => hasAlertedAllies = value; }
    public float AlertShoutRadius { get => alertShoutRadius; set => alertShoutRadius = value; }
    public float AlertShoutCooldown { get => alertShoutCooldown; set => alertShoutCooldown = value; }
    public float LastAlertShoutTime => lastAlertShoutTime;
    public List<KnownEnemyRecord> LocalKnownEnemies => localKnownEnemies;

    public IReadOnlyList<KnownEnemyRecord> KnownEnemies
    {
        get
        {
            if (IsScoutingActive)
            {
                return localKnownEnemies;
            }
            if (HasSquadLeader && SquadMember.Leader.Blackboard != null)
            {
                return SquadMember.Leader.Blackboard.KnownEnemies;
            }
            return localKnownEnemies;
        }
    }

    public bool IsScoutingActive => SquadMember != null && (SquadMember.IsScouting || SquadOrder == SquadOrderType.ScoutAhead);

    public bool HasKnownEnemies
    {
        get
        {
            if (HasSquadLeader && SquadMember.Leader.Blackboard != null)
            {
                return SquadMember.Leader.Blackboard.HasKnownEnemies;
            }
            return localKnownEnemies.Count > 0;
        }
    }

    public bool HasSquadLeader => SquadMember != null && SquadMember.HasLeader;
    public SquadOrderType SquadOrder => SquadMember != null ? SquadMember.CurrentOrder : SquadOrderType.None;
    public Transform FocusFireTarget => SquadMember != null ? SquadMember.FocusFireTarget : null;
    public Transform LeaderTransform => SquadMember != null ? SquadMember.LeaderTransform : null;
    public Vector3 SquadRallyPoint => SquadMember != null ? SquadMember.RallyPoint : transform.position;

    [SerializeField] private Vector3 spawnPosition;
    public Vector3 SpawnPosition { get => spawnPosition; set => spawnPosition = value; }

    [SerializeField] private int threatLevel;
    [SerializeField] private int fearLevel;
    [SerializeField] private float agentLife;
    [SerializeField] private float agentMana;

    public int ThreatLevel { get => threatLevel; private set => threatLevel = value; }
    public int FearLevel { get => fearLevel; private set => fearLevel = value; }
    public float AgentLife { get => agentLife; private set => agentLife = value; }
    public float AgentMana { get => agentMana; private set => agentMana = value; }

    public int EnemiesInSkillRange(float range)
    {
        if (enemyTargets == null || enemyTargets.Count == 0) return 0;
        int count = 0;
        for (int i = 0; i < enemyTargets.Count; i++)
        {
            if (enemyTargets[i] != null && Vector3.Distance(transform.position, enemyTargets[i].position) <= range)
                count++;
        }
        return count;
    }

#if UNITY_EDITOR
    [Header("Debugging")]
    [SerializeField] private string currentGoalKey = EnumUtilGoal.None.ToString();
    [SerializeField] private SerializableDictionary<EnumUtilGoal, float> goalScores = new();
    [SerializeField] private string currentSkillKey = "None";
    [SerializeField] private float currentSkillScore = 0f;
    [SerializeField] private SerializableDictionary<string, float> skillScores = new();
#endif

    private void Awake()
    {
        this.goap = FindAnyObjectByType<GoapBehaviour>();
        this.provider = this.GetComponent<GoapActionProvider>();

        if (this.provider.AgentTypeBehaviour == null && this.goap != null)
            this.provider.AgentType = this.goap.GetAgentType(agentType);

        if (GetComponent<AIDecisionThrottler>() == null)
        {
            gameObject.AddComponent<AIDecisionThrottler>();
        }

        if (GetComponent<CharacterAIMemory>() == null && GetComponentInParent<CharacterAIMemory>() == null && GetComponentInChildren<CharacterAIMemory>() == null)
        {
            gameObject.AddComponent<CharacterAIMemory>();
        }
    }

    private void Start()
    {
        if (brain == null) brain = GetComponentInParent<CharacterBrain>();
        if (agentBehaviour == null) agentBehaviour = GetComponent<AgentBehaviour>();
        if (stats == null) stats = GetComponentInParent<CharacterStatsManager>();
        if (motionController == null) motionController = GetComponentInParent<CharacterMovementController>();
        if (agent == null) agent = GetComponentInParent<NavMeshAgent>();

        // Auto-find SkillController if not assigned
        if (skillController == null)
        {
            skillController = GetComponent<CharacterSkillController>();
            if (skillController == null) skillController = GetComponentInChildren<CharacterSkillController>();
            if (skillController == null) skillController = GetComponentInParent<CharacterSkillController>();
            if (skillController == null && transform.root != null) skillController = transform.root.GetComponentInChildren<CharacterSkillController>();
        }

        // Auto-find VisionController if not assigned
        if (vision == null)
        {
            vision = GetComponent<VisionController>();
            if (vision == null) vision = GetComponentInChildren<VisionController>();
            if (vision == null) vision = GetComponentInParent<VisionController>();
            if (vision == null && transform.root != null) vision = transform.root.GetComponentInChildren<VisionController>();
        }

        // Auto-find CharacterAIMemory if not assigned
        if (aiMemory == null)
        {
            aiMemory = GetComponent<CharacterAIMemory>();
            if (aiMemory == null) aiMemory = GetComponentInChildren<CharacterAIMemory>();
            if (aiMemory == null) aiMemory = GetComponentInParent<CharacterAIMemory>();
            if (aiMemory == null && transform.root != null) aiMemory = transform.root.GetComponentInChildren<CharacterAIMemory>();
        }

        if (spawnPosition == Vector3.zero)
        {
            spawnPosition = transform.position;
        }

        InitializeAgent();
        InitializeSkills();
    }

    private void Update()
    {
        // Physics, agent movement, and resource stats update smoothly every frame
        UpdateResources();

        if (currentTarget != null)
        {
            targetDistance = Vector3.Distance(transform.position, currentTarget.position);
        }
        else
        {
            targetDistance = 0f;
        }
    }

    /// <summary>
    /// Evaluates Utility AI goals and requests the best goal from GOAP.
    /// Called at throttled intervals by <see cref="AIDecisionThrottler"/>.
    /// </summary>
    public void PerformStrategicDecision()
    {
        SetGoal();
    }

    /// <summary>
    /// Resets navigation, stops the active GOAP action, and clears the active goal on severe events.
    /// </summary>
    public void InterruptCurrentPlan()
    {
        activeGoal = EnumUtilGoal.None;

        if (agentBehaviour != null)
        {
            agentBehaviour.StopAction(false);
        }

        IsAgentStop(true);
    }

    private void InitializeAgent()
    {
        agent.updateRotation = false;
        agent.updateUpAxis = false;
        agent.speed = stats.Movespeed.Value;
    }

    /// <summary>
    /// Collects all UtilitySkill ScriptableObjects from the CharacterSkillController's skill list
    /// and populates the internal <see cref="skills"/> list automatically.
    /// Call this again if skills are added/removed at runtime.
    /// </summary>
    public void InitializeSkills()
    {
        skills.Clear();

        if (skillController == null) return;

        foreach (var skill in skillController.Skills)
        {
            if (skill == null) continue;

            UtilitySkill utilData = skill.UtilityData;
            if (utilData != null && !skills.Contains(utilData))
            {
                skills.Add(utilData);
            }
        }

#if UNITY_EDITOR
        if (skills.Count == 0)
            Debug.LogWarning($"[BaseAI] {name}: No UtilitySkill data found. " +
                             $"Make sure each SkillCaster's SkillData has a 'utilityData' ScriptableObject assigned, " +
                             $"or that the UtilitySkillRuntimeDatabase contains matching entries.");
        else
            Debug.Log($"[BaseAI] {name}: Initialized {skills.Count} utility skill(s): " +
                      string.Join(", ", skills.ConvertAll(s => s.GetID())));
#endif
    }

    // Emotional state Method
#region Emotional State

    private void CalculateEmotionalState()
    {
        
    }

    public void SenseEnemy()
    {
        // Increase threat level when sensing an enemy, scaled by trait/race
        threatLevel += Mathf.RoundToInt(10 * EffectiveThreatMultiplier);

        if (IsFearLocked)
        {
            fearLevel = Mathf.RoundToInt(Personality.Snapshot.LockedFearValue);
        }
        else
        {
            fearLevel += Mathf.RoundToInt(5 * EffectiveFearMultiplier);
        }
    }

    public void LostEnemy()
    {
        // Decrease threat level when losing sight of an enemy
        threatLevel = Mathf.Max(0, threatLevel - Mathf.RoundToInt(10 * EffectiveThreatMultiplier));

        if (IsFearLocked)
        {
            fearLevel = Mathf.RoundToInt(Personality.Snapshot.LockedFearValue);
        }
        else
        {
            fearLevel = Mathf.Max(0, fearLevel - Mathf.RoundToInt(5 * EffectiveFearMultiplier));
        }
    }

#endregion

    public void UpdateTargets()
    {
        if (vision != null)
        {
            enemyTargets = vision.EnemyTargets;
            allyTargets = vision.AllyTargets;
        }

        float currentTime = Time.time;

        // Synchronize directly seen enemies into known enemies
        if (enemyTargets != null && enemyTargets.Count > 0)
        {
            for (int i = 0; i < enemyTargets.Count; i++)
            {
                var enemy = enemyTargets[i];
                if (enemy == null) continue;

                // Update local known enemies
                bool existsLocally = false;
                for (int j = 0; j < localKnownEnemies.Count; j++)
                {
                    if (localKnownEnemies[j].Target == enemy)
                    {
                        var record = localKnownEnemies[j];
                        record.UpdatePosition(enemy.position, currentTime);
                        localKnownEnemies[j] = record;
                        existsLocally = true;
                        break;
                    }
                }
                if (!existsLocally)
                {
                    localKnownEnemies.Add(new KnownEnemyRecord(enemy, enemy.position, currentTime));
                }

                // If in squad, report to squad blackboard
                if (HasSquadLeader && SquadMember.Leader.Blackboard != null)
                {
                    SquadMember.Leader.Blackboard.ReportEnemy(enemy, enemy.position, currentTime);
                }
            }

            // If we have spotted enemies and shout cooldown has elapsed, mark unalerted to allow alert shout
            if (hasAlertedAllies && (currentTime - lastAlertShoutTime) >= alertShoutCooldown)
            {
                hasAlertedAllies = false;
            }
        }

        // Prune expired local known enemies
        for (int i = localKnownEnemies.Count - 1; i >= 0; i--)
        {
            if (!localKnownEnemies[i].IsValid(currentTime))
            {
                localKnownEnemies.RemoveAt(i);
            }
        }

        // Check if current target broke direct visual contact: record last known position
        if (currentTarget != null && (enemyTargets == null || !enemyTargets.Contains(currentTarget)))
        {
            if (AIMemory != null)
            {
                AIMemory.RecordLastKnownPosition(currentTarget, currentTarget.position, 6f);
            }
        }

        // Ghost threat cleanup: if no enemies remain in direct perception, known enemies, or last known target memory, clean up threat/fear
        bool hasMemoryTarget = AIMemory != null && AIMemory.HasLastKnownTarget;
        if ((enemyTargets == null || enemyTargets.Count == 0) && !HasKnownEnemies && !hasMemoryTarget && threatLevel > 0)
        {
            threatLevel = 0;
            if (!IsFearLocked)
            {
                fearLevel = 0;
            }
            hasAlertedAllies = true;
        }
    }

    public void ReceiveAlert(Transform enemy, Vector3 lastKnownPosition, float duration = 6f)
    {
        if (enemy == null) return;

        float currentTime = Time.time;
        bool existsLocally = false;
        for (int i = 0; i < localKnownEnemies.Count; i++)
        {
            if (localKnownEnemies[i].Target == enemy)
            {
                var record = localKnownEnemies[i];
                record.UpdatePosition(lastKnownPosition, currentTime);
                localKnownEnemies[i] = record;
                existsLocally = true;
                break;
            }
        }
        if (!existsLocally)
        {
            localKnownEnemies.Add(new KnownEnemyRecord(enemy, lastKnownPosition, currentTime, duration));
        }

        if (!IsScoutingActive && HasSquadLeader && SquadMember.Leader.Blackboard != null)
        {
            SquadMember.Leader.Blackboard.ReportEnemy(enemy, lastKnownPosition, currentTime, duration);
        }

        // Elevate ThreatLevel to enter combat readiness stance
        threatLevel = Mathf.Max(threatLevel, Mathf.RoundToInt(15 * EffectiveThreatMultiplier));
    }

    public void PerformAlertShout()
    {
        hasAlertedAllies = true;
        lastAlertShoutTime = Time.time;

        Transform primaryTarget = currentTarget;
        if (primaryTarget == null && enemyTargets != null && enemyTargets.Count > 0)
        {
            primaryTarget = enemyTargets[0];
        }
        else if (primaryTarget == null && HasKnownEnemies)
        {
            var known = KnownEnemies;
            if (known.Count > 0) primaryTarget = known[0].Target;
        }

        Vector3 targetPos = primaryTarget != null ? primaryTarget.position : transform.position;

        OnAlertShout?.Invoke(primaryTarget);

        // If scout is on active reconnaissance, do not alert squad or shout to allies
        if (IsScoutingActive)
        {
            return;
        }

        // 1. Squad Communication: Notify squad leader and all fellow squad members
        if (HasSquadLeader && SquadMember.Leader != null)
        {
            var leader = SquadMember.Leader;
            if (primaryTarget != null)
            {
                leader.Blackboard.ReportEnemy(primaryTarget, targetPos, lastAlertShoutTime);
            }

            var leaderAI = leader.GetComponentInChildren<BaseAI>();
            if (leaderAI != null && leaderAI != this)
            {
                leaderAI.ReceiveAlert(primaryTarget, targetPos);
            }

            var members = leader.Members;
            if (members != null)
            {
                for (int i = 0; i < members.Count; i++)
                {
                    var m = members[i];
                    if (m != null && m.IsAlive && m.BaseAI != null && m.BaseAI != this)
                    {
                        m.BaseAI.ReceiveAlert(primaryTarget, targetPos);
                    }
                }
            }
        }

        // 2. Proximity Alert Broadcast: Alert nearby non-squad allies within shout radius
        var factionMember = GetComponentInParent<FactionMember>();
        int hitCount = Physics2D.OverlapCircleNonAlloc(transform.position, alertShoutRadius, proximityAlertBuffer);
        for (int i = 0; i < hitCount; i++)
        {
            var col = proximityAlertBuffer[i];
            if (col == null) continue;

            bool isAlly = false;
            if (factionMember != null)
            {
                isAlly = factionMember.IsAllyOf(col.gameObject);
            }
            else
            {
                if ((CompareTag("Adventurer") && col.CompareTag("Adventurer")) ||
                    (CompareTag("Monster") && col.CompareTag("Monster")))
                {
                    isAlly = true;
                }
            }

            if (isAlly)
            {
                var allyAI = col.GetComponentInChildren<BaseAI>() ?? col.GetComponentInParent<BaseAI>();
                if (allyAI != null && allyAI != this)
                {
                    allyAI.ReceiveAlert(primaryTarget, targetPos);
                }
            }
        }
    }

    public void UpdateResources()
    {
        if (stats != null)
        {
            agentLife = stats.Life;
            agentMana = stats.Mana;
        }
    }

    public void SetTarget(Transform target)
    {
        CurrentTarget = target;
        TargetDistance = target != null ? Vector3.Distance(transform.position, target.position) : 0f;
    }

    public void SetTarget(Transform target, float distance)
    {
        CurrentTarget = target;
        TargetDistance = distance;
    }

    public void SetAgentLife(float life) => AgentLife = life;
    public void SetAgentMana(float mana) => AgentMana = mana;
    public void SetFearLevel(int level) => FearLevel = level;

    public void SetGoal(bool force = false)
    {
        EnumUtilGoal bestGoal = SelectBestGoal();
        if (bestGoal == EnumUtilGoal.None)
        {
            activeGoal = EnumUtilGoal.None;
            return;
        }

        bool goalChanged = bestGoal != activeGoal;
        bool hasNoActiveAction = agentBehaviour != null && agentBehaviour.ActionState.Action == null;

        if (force || goalChanged || hasNoActiveAction)
        {
            activeGoal = bestGoal;
            Planner(bestGoal);
        }
    }

    public void AgentDestination(Vector2 targetPosition)
    {
        if (agent != null && agent.isActiveAndEnabled && agent.isOnNavMesh)
        {
            agent.SetDestination(targetPosition);
        }
    }

    public bool IsAgentStop(bool value)
    {
        if (agent != null && agent.isActiveAndEnabled && agent.isOnNavMesh)
        {
            return agent.isStopped = value;
        }
        return false;
    }

    private EnumUtilGoal SelectBestGoal()
    {
        UtilityGoal bestGoal = null;
        float highestScore = 0f;

#if UNITY_EDITOR
        goalScores.Clear();
#endif

        for (int i = 0; i < goals.Count; i++)
        {
            var goal = goals[i];
            if (goal == null) continue;

            float score = goal.Evaluate(this);

            if (score > highestScore)
            {
                highestScore = score;
                bestGoal = goal;
            }

#if UNITY_EDITOR
            goalScores.GetPairs().Add(new SerializableDictionary<EnumUtilGoal, float>.Pair
            {
                Key = goal.GetGOAPGoalKey(),
                Value = score
            });
#endif
        }

#if UNITY_EDITOR
        currentGoalKey = bestGoal != null ? bestGoal.GetGOAPGoalKey().ToString() : EnumUtilGoal.None.ToString();
#endif

        return bestGoal != null ? bestGoal.GetGOAPGoalKey() : EnumUtilGoal.None;
    }

    /// <summary>
    /// Selects the best UtilitySkill from the auto-populated skills list (sourced from CharacterSkillController).
    /// Called by CharacterSkillController.TryCastSkillAI().
    /// </summary>
    public UtilitySkill SelectBestSkill()
    {
        return SelectBestSkill(skills);
    }

    /// <summary>
    /// Selects the best UtilitySkill from an explicit list. Useful if you want to pass a custom subset.
    /// </summary>
    public UtilitySkill SelectBestSkill(List<UtilitySkill> utilSkills)
    {
        if (utilSkills == null || utilSkills.Count == 0)
        {
#if UNITY_EDITOR
            currentSkillKey = "None";
            currentSkillScore = 0f;
            skillScores.Clear();
#endif
            return null;
        }

        UtilitySkill bestUtilSkill = null;
        float highestScore = 0f;

#if UNITY_EDITOR
        skillScores.Clear();
#endif

        foreach (var utilSkill in utilSkills)
        {
            if (utilSkill == null) continue;
            float score = utilSkill.Evaluate(this);

#if UNITY_EDITOR
            skillScores.GetPairs().Add(new SerializableDictionary<string, float>.Pair
            {
                Key = utilSkill.GetID(),
                Value = score
            });
#endif

            if (score > highestScore)
            {
                highestScore = score;
                bestUtilSkill = utilSkill;
            }
        }

#if UNITY_EDITOR
        currentSkillKey = bestUtilSkill != null ? bestUtilSkill.GetID() : "None";
        currentSkillScore = bestUtilSkill != null ? highestScore : 0f;
#endif

        return bestUtilSkill;
    }

#if UNITY_EDITOR
    /// <summary>
    /// Records a fallback skill execution in the inspector when no UtilitySkill scored > 0.
    /// </summary>
    public void RecordFallbackSkill(string skillId)
    {
        currentSkillKey = string.IsNullOrEmpty(skillId) ? "[Fallback]" : $"[Fallback] {skillId}";
        currentSkillScore = 0f;
    }
#endif

#region Planner

    private void Planner(EnumUtilGoal goalKey)
    {
        if (provider == null || provider.AgentType == null) return;

        switch (goalKey)
        {
            case EnumUtilGoal.Wander:
                provider.RequestGoal<IdleGoal>();
                break;
            case EnumUtilGoal.KillEnemy:
                provider.RequestGoal<KillEnemyGoal>();
                break;
            case EnumUtilGoal.FollowLeader:
                provider.RequestGoal<FollowLeaderGoal>();
                break;
            case EnumUtilGoal.FocusFire:
                provider.RequestGoal<FocusFireGoal>();
                break;
            case EnumUtilGoal.FallBack:
                provider.RequestGoal<FallBackGoal>();
                break;
            case EnumUtilGoal.Survive:
                provider.RequestGoal<SurviveGoal>();
                break;
            case EnumUtilGoal.KeepDistance:
                provider.RequestGoal<KeepDistanceGoal>();
                break;
            case EnumUtilGoal.Standby:
                provider.RequestGoal<StandbyGoal>();
                break;
            case EnumUtilGoal.AlertAllies:
                provider.RequestGoal<AlertAlliesGoal>();
                break;
            case EnumUtilGoal.ScoutRecon:
                provider.RequestGoal<ScoutReconGoal>();
                break;
            case EnumUtilGoal.DebriefLeader:
                provider.RequestGoal<DebriefLeaderGoal>();
                break;
            default:
                Debug.LogWarning("Unknown utility goal: " + goalKey);
                break;
        }
    }
#endregion

    /// <summary>
    /// Computes a trait-weighted target utility score for a given target transform without managed allocations.
    /// Incorporates low-health priority (Bloodthirsty/Beast) and distance weighting.
    /// </summary>
    public float GetTraitWeightedTargetScore(Transform target, float distance)
    {
        if (target == null) return 0f;

        // Base proximity score (closer = higher)
        float score = 100f / (1f + distance);

        // Low health execution bias
        if (LowHealthTargetPriority > 1f && target.TryGetComponent<CharacterStatsManager>(out var targetStats))
        {
            if (targetStats.MaxLife != null && targetStats.MaxLife.Value > 0f)
            {
                float targetHpPercent = targetStats.Life / targetStats.MaxLife.Value;
                if (targetHpPercent <= ExecutionHealthThreshold)
                {
                    score *= LowHealthTargetPriority;
                }
            }
        }

        // Dual-Layer Memory: Grudge & Retaliation weighting
        if (AIMemory != null)
        {
            int targetId = target.gameObject.GetEntityId().GetHashCode();
            float grudge = AIMemory.GetGrudgeScore(targetId);
            if (grudge > 0f)
            {
                score += grudge;
            }

            // Rapid retaliation bonus against immediate attacker within window
            if (AIMemory.HasRecentAttacker && AIMemory.LastAttackerTransform == target)
            {
                float grudgeMultiplier = Personality != null ? Personality.Snapshot.GrudgeWeightMultiplier : 1.0f;
                score += 50f * grudgeMultiplier;
            }
        }

        return score;
    }
}